<?php 

foreach ($trabajadores as $key) {
  echo $key->id;
  echo $key->nombre;
  echo $key->ap;
 
}
?>
<?php echo "<br>";?>
<?php
foreach ($peonetas as $key2) {
  echo $key2->id;
  echo $key2->nombre;
  echo $key2->ap; 
}
?>
<?php echo "<br>";?>
<?php
foreach ($peonetas_2 as $key3) {
  echo $key3->id;
  echo $key3->nombre;
  echo $key3->ap; 
}
?>
<?php echo "<br>";?>
<?php
foreach ($peonetas_3 as $key4) {
  echo $key4->id;
  echo $key4->nombre;
  echo $key4->ap; 
}
?>
<?php
foreach ($peonetas_4 as $key5) {
  echo $key5->id;
  echo $key5->nombre;
  echo $key5->ap; 
}
?>