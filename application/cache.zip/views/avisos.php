<div class="blank_start">
	<div class="cerrar"><a href="#">x</a></div>
  <h1>				    
      <?php echo @$titulo ?>			    
  </h1>
  <p><?php echo @$comentario ?></p>
</div>