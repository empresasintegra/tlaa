<li><a href="<?php echo base_url() ?>usuarios/home"><i class="fa fa-home"></i> <span class="title" > Inicio </span></a> 
</li>

<!--<li><a href="javascript:void(0)"><i class="fa fa-desktop"></i> <span class="title">Mantenedores</span><i class="icon-arrow"></i></a>
	<ul class="sub-menu">		
		<li><a href="<?php //echo base_url() ?>transportes/cargos/"><i class="fa fa-briefcase"></i>Cargos</span></a></li>
		<li><a href="<?php //echo base_url() ?>transportes/rutas/"><i class="fa fa-road"></i> Rutas</span></a></li>
		<li><a href="<?php //echo base_url() ?>transportes/camion/"><i class="fa fa-truck"></i> Camiones</span></a></li>
		<li><a href="<?php //echo base_url() ?>transportes/codigos_ccu/"><i class="fa fa-barcode" aria-hidden="true"></i> Codigos CCU</span></a></li>
		<li><a href="<?php //echo base_url() ?>transportes/colectivo/"><i class="fa fa-share-alt" aria-hidden="true"></i> Colectivo</span></a></li>
		<li><a href="<?php //echo base_url() ?>transportes/trabajador/datos_trabajadores"><i class="fa fa-user"></i> Trabajadores</span></a></li>
		<li><a href="<?php //echo base_url() ?>transportes/asignacion/asignacion_trabajadores"><i class="fa fa-users"></i> Asignación</span></a></li>
    </ul> 
</li>-->
<!--<li><a href="<?php //echo base_url() ?>transportes/datos/resumen_trabajadores"><i class="fa fa-upload"></i> <span  class="title"> Ingreso Producción</span></a></li>-->

<li><a href="javascript:void(0)"><i class="fa fa-briefcase"></i> <span class="title" > Informes</span><i class="icon-arrow"></i> </a>
	<ul class="sub-menu">		
		<li><a href="<?php echo base_url() ?>transportes/informes/asistencia"><i class="fa fa-user"></i> Asistencia Trabajadores</a></li>
	</ul>
	<li><a href="<?php echo base_url() ?>transportes/ayuda/menu"><i class="fa fa-user"></i> ayuda</a></li>
</li>
