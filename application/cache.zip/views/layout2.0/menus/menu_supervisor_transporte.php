<li><a href="<?php echo base_url() ?>usuarios/home"><i class="fa fa-home"></i> <span class="title" > Inicio </span></a>
</li>


<li><a href="<?php echo base_url() ?>transportes/datos/resumen_trabajadores"><i class="fa fa-upload"></i> <span  class="title"> Ingreso Producción</span></a></li>
>
<li><a href="<?php echo base_url() ?>transportes/informes/asistencia"><i class="fa fa-user"></i> Asistencia Trabajadores</a></li>

<!--<li><a href="<?php //echo base_url() ?>transportes/ranking/informe/"><i class="fa fa-home"></i> <span class="title"> Informe 1 al 20 Dic</span></a></li>-->
<li><a href="javascript:void(0)"><i class="fa fa-briefcase"></i> <span class="title" > Reportes</span><i class="icon-arrow"></i> </a>
	<ul class="sub-menu">		
		<li><a href="<?php echo base_url() ?>transportes/reportes/cajas"><i class="fa fa-user"></i> Cajas Movidas</a></li> 
		<!--<li><a href="<?php //echo base_url() ?>transportes/resumen/resumen_produccion"><i class="fa fa-user"></i> Liquidaciones de Sueldo </a></li>
		<li><a href="<?php //echo base_url() ?>transportes/produccion/consolidado_produccion"><i class="fa fa-user"></i> Resumen de Producción </a></li>-->
	</ul>
	<li><a href="<?php echo base_url() ?>transportes/ayuda/menu"><i class="fa fa-user"></i> ayuda</a></li>
</li>
