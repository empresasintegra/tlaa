<li><a href="<?php echo base_url() ?>usuarios/home"><i class="fa fa-home"></i> <span class="title" > Inicio </span></a> 
</li>


<li><a href="javascript:void(0)"><i class="fa fa-desktop"></i> <span class="title">Mantenedores</span><i class="icon-arrow"></i></a>
	<ul class="sub-menu">		
	
		<li><a href="<?php echo base_url() ?>transportes/repuestos/index"><i class="fa fa-cog" aria-hidden="true"></i> Repuestos </span></a></li>
		<li><a href="<?php echo base_url() ?>transportes/proveedores/index"><i class="fa fa-building-o " aria-hidden="true"></i> proveedores </span></a></li>
		<li><a href="<?php echo base_url() ?>transportes/nombre_mantencion/index"><i class="fa fa-building-o " aria-hidden="true"></i> Detalles Mantenciones </span></a></li>
    </ul> 
</li>

<li><a href="<?php echo base_url() ?>transportes/mantenciones/index"><i class="fa fa-tachometer" aria-hidden="true"></i> Mantenciones</span></a></li>
<li><a href="<?php echo base_url() ?>transportes/ayuda/menu"><i class="fa fa-user"></i> ayuda</a></li>