<li><a href="<?php echo base_url() ?>usuarios/home"><i class="fa fa-home"></i> <span class="title" > Inicio </span></a></li>

<li><a href="javascript:void(0)"><i class="fa fa-desktop"></i> <span class="title">Mantenedores</span><i class="icon-arrow"></i></a>
	<ul class="sub-menu">		
		<li><a href="<?php echo base_url() ?>transportes/cargos/"><i class="fa fa-briefcase"></i>Cargos</span></a></li>
		<li><a href="<?php echo base_url() ?>transportes/rutas/"><i class="fa fa-road"></i> Rutas</span></a></li>
		<li><a href="<?php echo base_url() ?>transportes/camion/"><i class="fa fa-truck"></i> Camiones</span></a></li>
		<li><a href="<?php echo base_url() ?>transportes/codigos_ccu/"><i class="fa fa-barcode" aria-hidden="true"></i> Codigos CCU</span></a></li>
		<li><a href="<?php echo base_url() ?>transportes/trabajador/datos_trabajadores"><i class="fa fa-user"></i> Trabajadores</span></a></li>		
    </ul>
</li>

<li><a href="<?php echo base_url() ?>transportes/datos/resumen_trabajadores"><i class="fa fa-upload"></i> <span  class="title">Ingreso Producción</span></a></li>
<li><a href="<?php echo base_url() ?>transportes/informes/asistencia"><i class="fa fa-user"></i> Asistencia Trabajadores</a></li>
<li><a href="<?php echo base_url() ?>transportes/informes/resumen_preventa_rechazo"><i class="fa fa-tachometer" aria-hidden="true"></i> Resumen Preventa y Rechazo </span></a></li>
<li><a href="<?php echo base_url() ?>transportes/ranking/ranking_ingreso"><i class="fa fa-upload"></i> <span  class="title"> Ingreso Ranking</span></a></li>
<li><a href="javascript:void(0)"><i class="fa fa-briefcase"></i> <span class="title" > Reportes</span><i class="icon-arrow"></i> </a>
	<ul class="sub-menu">		
		<li><a href="<?php echo base_url() ?>transportes/reportes/cajas"><i class="fa fa-user"></i> Cajas Movidas</a></li> 
		<!--<li><a href="<?php //echo base_url() ?>transportes/resumen/resumen_produccion"><i class="fa fa-user"></i> Liquidaciones de Sueldo </a></li>
		<li><a href="<?php //echo base_url() ?>transportes/produccion/consolidado_produccion"><i class="fa fa-user"></i> Resumen de Producción </a></li>-->
	</ul>
</li>
 